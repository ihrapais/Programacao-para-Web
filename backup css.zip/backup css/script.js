// Meu script para funcionalidades da página
document.addEventListener('DOMContentLoaded', function() {
  const themeToggleBtn = document.getElementById('theme-toggle');
  const body = document.body;
  const currentYearSpan = document.getElementById('currentYear');

  // Função para aplicar o tema (claro ou escuro)
  function setTheme(theme) {
    if (theme === 'dark') {
      body.classList.add('dark-mode'); // Adiciona classe para tema escuro
      themeToggleBtn.textContent = 'Mudar para Tema Claro';
    } else {
      body.classList.remove('dark-mode'); // Remove classe para tema claro
      themeToggleBtn.textContent = 'Mudar para Tema Escuro';
    }
  }

  // Carrega o tema salvo no navegador (se houver)
  const savedTheme = localStorage.getItem('theme');
  if (savedTheme) {
    setTheme(savedTheme); // Aplica tema salvo
  } else {
    setTheme('light'); // Padrão: tema claro
  }

  // Ação ao clicar no botão de tema
  themeToggleBtn.addEventListener('click', function() {
    let newTheme;
    if (body.classList.contains('dark-mode')) {
      newTheme = 'light'; // Se está escuro, muda para claro
    } else {
      newTheme = 'dark'; // Se está claro, muda para escuro
    }
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme); // Salva nova preferência
  });

  // Atualiza o ano no rodapé
  if (currentYearSpan) {
    currentYearSpan.textContent = new Date().getFullYear(); // Pega o ano atual
  }
});
